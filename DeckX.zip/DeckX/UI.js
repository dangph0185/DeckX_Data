"auto";

// Kiểm tra trùng lặp ngay khi vừa mở run.js
var currentEngines = engines.all();
var runningCount = 0;
for (var i = 0; i < currentEngines.length; i++) {
    if (currentEngines[i].getSource().toString().indexOf("UI.js") > -1) {
        runningCount++;
    }
}
if (runningCount > 1) {
    exit();
}

/* ===== Đường dẫn tài nguyên ===== */
var DIR           = "/sdcard/Pictures/DeckX";
var CONFIG_PATH   = DIR + "/config.json";
var TEMPLATES_DIR = DIR + "/templates";
var SCRIPT_ALL    = DIR + "/AllScr.js"; 

/* ===== Dữ liệu Danh sách Chọn ===== */
var DanhSach120 = []; for (var i = 100; i <= 120; i++) { DanhSach120.push(String(i)); }
var BuyRaid_Data = ["0","1","2","3","4","5"];
var Delay_Name = ["0.1","0.5","1","2","3","4","5","6","7","8","9","10"];
var DiemGlory  = ["10000","15000","20000","25000", "30000","35000","40000","45000","50000"];

/* ===== Hàm bổ trợ & Rung ===== */
function readJson(p, fb){ try{ if(files.exists(p)) return JSON.parse(String(files.read(p))); }catch(e){} return fb; }
function writeJson(p, o){ try{ files.ensureDir(p.replace(/\/[^/]+$/, "")); files.write(p, JSON.stringify(o, null, 2));  }catch(e){ toast("✖ Lỗi lưu"); } }
function dp(v){ try{ var s=context.getResources().getDisplayMetrics().density; return Math.round(v*s); }catch(e){ return v; } }
function clickVibrate() { try { device.vibrate(45); } catch(e) {} }

function makeRoundDrawable(bgColor, radiusPx, strokePx, strokeColor){
  var gd = new android.graphics.drawable.GradientDrawable();
  gd.setColor(android.graphics.Color.parseColor(bgColor)); 
  gd.setCornerRadius(radiusPx); 
  if(strokePx) gd.setStroke(strokePx, android.graphics.Color.parseColor(strokeColor)); 
  return gd;
}
function cap(s) { if (!s) return ""; return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase(); }
function tintCheckboxWhite(cb){
  try{
    var CSL = android.content.res.ColorStateList;
    var white = CSL.valueOf(android.graphics.Color.WHITE);
    if (cb.setButtonTintList) cb.setButtonTintList(white);
  }catch(e){}
  try{ cb.setTextColor(android.graphics.Color.WHITE); }catch(e){}
}

function rowPick(label, rowId, valId){
  return '<horizontal id="container_'+valId+'" w="*" h="40dp" marginBottom="5dp" visibility="gone">' +
    '<frame w="0" layout_weight="1.2" h="*" padding="8dp" bg="#33000000">' +
      '<text text="'+label+'" textColor="#FFFFFF" textSize="11sp" gravity="center_vertical"/>' +
    '</frame>' +
    '<frame id="'+rowId+'" w="0" layout_weight="1" h="*" padding="8dp" bg="#55000000" clickable="true">' +
      '<horizontal w="*" h="*" gravity="center">' +
        '<text id="'+valId+'" text="-" textColor="#FFFFFF" textSize="12sp" textStyle="bold" gravity="center"/>' +
      '</horizontal>' +
    '</frame>' +
  '</horizontal>';
}

/* ===== XML CẤU TRÚC ===== */
var mini_xml = '<frame id="mw_move" w="wrap_content" h="wrap_content" visibility="gone" clickable="true"><img src="file://' + TEMPLATES_DIR + '/DH.png" w="40dp" h="40dp" scaleType="fitCenter"/></frame>';

var btnKeys = ['reward', 'trial', 'duel', 'gauntlet', 'explorer', 'mine', 'sky', 'raid'];

var ui_xml = '<frame id="fw_move" w="wrap_content" h="wrap_content" visibility="gone" clickable="true"><vertical id="toolbar_bg" padding="8dp" gravity="center"><text id="tw_title" text="AUTO DECKX - BY STORM" textColor="#FFFFFF" textSize="16sp" textStyle="bold" marginBottom="5dp" gravity="center"/><horizontal gravity="center">' + 
    btnKeys.map(k => 
        '<vertical id="btn_' + k + '" margin="2dp" gravity="center" clickable="true">' +
            '<frame id="icon_bg_' + k + '" padding="3dp">' +
                '<img src="file://' + TEMPLATES_DIR + '/' + k + '.png" w="40dp" h="40dp" scaleType="fitCenter"/>' +
            '</frame>' +
            '<text text="' + (k === 'duel' ? 'Duel' : cap(k)) + '" textColor="#FFFFFF" textSize="10sp" gravity="center" marginTop="2dp"/>' +
        '</vertical>').join('') + 
'<vertical id="btn_control" margin="2dp" gravity="center" clickable="true"><frame id="icon_bg_control" padding="3dp"><img id="img_control" src="file://' + TEMPLATES_DIR + '/setting.png" w="40dp" h="40dp" scaleType="fitCenter"/></frame><text id="txt_control" text="Setting" textColor="#FFFFFF" textSize="10sp" gravity="center" marginTop="2dp"/></vertical>' + 
'<vertical id="btn_update" margin="2dp" gravity="center" clickable="true"><frame id="icon_bg_update" padding="3dp"><img src="file://' + TEMPLATES_DIR + '/update.png" w="40dp" h="40dp" scaleType="fitCenter"/></frame><text text="Update" textColor="#FFFFFF" textSize="10sp" gravity="center" marginTop="2dp"/></vertical>' + 
'<vertical id="btn_mini" margin="2dp" gravity="center" clickable="true"><frame padding="3dp"><img src="file://' + TEMPLATES_DIR + '/mini.png" w="40dp" h="40dp" scaleType="fitCenter"/></frame><text text="Mini" textColor="#FFFFFF" textSize="10sp" gravity="center" marginTop="2dp"/></vertical>' + 
'<vertical id="btn_exit" margin="2dp" gravity="center" clickable="true"><frame padding="3dp"><img src="file://' + TEMPLATES_DIR + '/exit.png" w="40dp" h="40dp" scaleType="fitCenter"/></frame><text text="Exit" textColor="#FFFFFF" textSize="10sp" gravity="center" marginTop="2dp"/></vertical>' + 
'</horizontal></vertical></frame>';

var pw_xml = '<frame id="pw_move" w="wrap_content" h="wrap_content" visibility="gone" clickable="true"><frame id="pw_card" w="220dp" h="wrap_content"><vertical id="layout_setting" w="*" h="*" padding="12dp" gravity="center" visibility="visible"><text id="pw_title" text="CẤU HÌNH" textColor="#FFFFFF" textSize="15sp" textStyle="bold" marginBottom="20dp" gravity="center" w="*"/><scroll h="150dp" scrollbars="none"><vertical>' + rowPick("TG ĐỢI (S)", "rowDelay", "valDelay") + rowPick("MUA RAID", "rowBuyRaid", "valBuyRaid") + rowPick("MỐC GLORY", "rowDiemGlory", "valDiemGlory") + rowPick("MAP ĐẦU", "rowMBatdau", "valMBatdau") + rowPick("MAP CUỐI", "rowMKetthuc", "valMKetthuc") + '<horizontal id="checkbox_area" w="*" marginTop="5" visibility="gone"><vertical w="0" layout_weight="1"><checkbox id="cbDoiOre" text="Đổi sang ore" /><checkbox id="cbClaimRe" text="Nhận Air" /><checkbox id="cbBuyBazaar" text="Mua Bazaar" /><checkbox id="cbBuySky" text="Mua thêm lượt" /><checkbox id="cbBuyDuel" text="Mua thêm lượt" /></vertical></horizontal></vertical></scroll></vertical><vertical id="layout_picker" w="*" h="*" padding="12dp" gravity="center" visibility="gone"><text id="picker_title" text="CHỌN GIÁ TRỊ" textColor="#FFFFFF" textSize="15sp" textStyle="bold" marginBottom="20dp" gravity="center" w="*"/><list id="picker_list" h="120dp" w="*"><vertical id="item_click" w="*" h="wrap_content" gravity="center" padding="10dp" bg="?attr/selectableItemBackground"><text text="{{this}}" textColor="#FFFFFF" textSize="16sp" gravity="center"/></vertical></list><button id="btn_picker_back" text="QUAY LẠI" w="*" h="40dp" marginTop="8dp" style="Widget.AppCompat.Button.Borderless" textColor="#FFFFFF"/></vertical></frame></frame>';

var run_xml = '<frame id="run_move" w="wrap_content" h="wrap_content" visibility="gone" clickable="true"><vertical id="run_bg" padding="5dp" gravity="center"><img id="run_img" w="40dp" h="40dp" scaleType="fitCenter"/><text text="RUNNING" textColor="#00FF00" textSize="7sp" textStyle="bold" gravity="center"/></vertical></frame>';

/* ===== KHỞI TẠO VÀ CĂN CHỈNH VỊ TRÍ ===== */
var mw = floaty.rawWindow(mini_xml); mw.setSize(0, 0); mw.setPosition(-1000, -1000);
var fw = floaty.rawWindow(ui_xml);   fw.setSize(0, 0); fw.setPosition(-1000, -1000);
var pw = floaty.rawWindow(pw_xml);   pw.setSize(0, 0); pw.setPosition(-1000, -1000);
var rw = floaty.rawWindow(run_xml);  rw.setSize(0, 0); rw.setPosition(-1000, -1000);

var TOOLBAR_WIDTH = dp(660); 

/* ===== HÀM CĂN CHỈNH VỊ TRÍ (FIX TRIỆT ĐỂ) ===== */
function fixMiniPosition() {
    ui.run(() => {
        // Ép hệ thống lấy lại thông số điểm ảnh thực tế ngay tại thời điểm gọi hàm
        var metrics = context.getResources().getDisplayMetrics();
        var sw = metrics.widthPixels;
        var sh = metrics.heightPixels;
        
        // Đặt kích thước nút DH là 40dp
        mw.setSize(dp(40), dp(40));
        
        // TÍNH TOÁN TỌA ĐỘ GÓC DƯỚI BÊN TRÁI:
        // X: Cách lề trái 15dp
        // Y: Lấy chiều cao thực (sh) trừ đi 85dp để nằm phía trên thanh điều hướng một chút
        var targetX = dp(15);
        var targetY = sh - dp(65); 

        mw.setPosition(targetX, targetY);
        mw.mw_move.setVisibility(0);
        
        // log để sếp kiểm tra trong mục Log nếu cần: 
        //toast("Đã fix tọa độ DH: " + targetX + ", " + targetY + " (Màn hình: " + sw + "x" + sh + ")");
    });
}

// Khởi tạo vị trí lần đầu
setTimeout(fixMiniPosition, 600);

/* ===== LUỒNG KIỂM TRA XOAY MÀN HÌNH DÙNG SW, SH ===== */
/* ===== LUỒNG KIỂM TRA XOAY MÀN HÌNH DÙNG SW, SH ===== */
threads.start(function() {
    function getDisplay() {
        var m = context.getResources().getDisplayMetrics();
        return { sw: m.widthPixels, sh: m.heightPixels };
    }

    var lastMetrics = getDisplay();

    while (true) {
        var current = getDisplay();
        if (current.sw !== lastMetrics.sw || current.sh !== lastMetrics.sh) {
            
            sleep(1000); // Đợi Poco ổn định layout
            
            var finalM = getDisplay();
            var sw = finalM.sw;
            var sh = finalM.sh; // FIX LỖI: Đổi .h thành .sh
            lastMetrics = finalM;

            // 1. Fix nút DH
            if (mw && mw.mw_move.getVisibility() === 0) {
                fixMiniPosition();
            }

            // 2. Fix Toolbar
            if (fw && fw.fw_move.getVisibility() === 0) {
                ui.run(() => { fw.setPosition((sw - TOOLBAR_WIDTH) / 2, dp(50)); });
            }

            // 3. Fix nút Running (Cùng tọa độ với nút DH cho đẹp)
            if (isRunning && rw && rw.run_move.getVisibility() === 0) {
                ui.run(() => {
                    rw.setSize(dp(70), dp(70));
                    // Căn chỉnh để tâm icon Running khớp với tâm icon DH
                    rw.setPosition(dp(15) - dp(15), sh - dp(65) - dp(15)); 
                });
            }
        }
        sleep(1000);
    }
});

setTimeout(() => {
    ui.run(() => {
        // Dự phòng tọa độ Toolbar
        fw.setPosition((device.width - TOOLBAR_WIDTH) / 2, dp(50));
    });
}, 200);

/* --- Biến logic --- */
var state = readJson(CONFIG_PATH, { delay: "0", buy_raid: "0", diemGlory_value: "35000", m_batdau: "100", m_ketthuc: "120", duel: false, gauntlet: false, explorer: false, flags: {} });
var isSettingMode = false;
var isRunning = false;
var currentPickerCb = null;

/* ===== LOGIC CLICK EXIT ===== */
fw.btn_exit.click(() => {
    setTimeout(() => { engines.stopAll(); }, 500);
});

/* ===== HÀM START RUNNING ===== */
function startRunning(btnName) {
    btnKeys.forEach(key => {
        state[key] = (key === btnName);
    });
    writeJson(CONFIG_PATH, state);
    
    if(files.exists(SCRIPT_ALL)) {
        engines.execScriptFile(SCRIPT_ALL);
    } else {
        toast("✖ Không tìm thấy AllScr.js");
    }

	isRunning = true;
    ui.run(() => {
        var metrics = context.getResources().getDisplayMetrics();
        var sh = metrics.heightPixels;

        rw.run_img.setSource("file://" + TEMPLATES_DIR + "/" + btnName + ".png");
        
        // Ẩn các cửa sổ khác
        fw.setSize(0, 0); fw.fw_move.setVisibility(8);
        pw.setSize(0, 0); pw.pw_move.setVisibility(8);
        mw.setSize(0, 0); mw.mw_move.setVisibility(8);
        
        // Hiện nút Running tại đúng vị trí DH vừa biến mất
        rw.setSize(dp(70), dp(70));
        rw.setPosition(dp(0), sh - dp(80)); // Tọa độ khởi tạo chuẩn
        rw.run_move.setVisibility(0);
    });
    threads.start(function(){
        while(isRunning){
            ui.run(()=> rw.run_bg.setAlpha(0.5)); sleep(600);
            ui.run(()=> rw.run_bg.setAlpha(1.0)); sleep(600);
        }
    });
}

function updateButtonHighlights(activeBtn) {
    ui.run(() => {
        btnKeys.forEach(k => {
            if (k === activeBtn) fw['icon_bg_' + k].setBackground(makeRoundDrawable("#44FFFFFF", dp(8), dp(1.2), "#FFFFFF"));
            else fw['icon_bg_' + k].setBackground(null);
        });
    });
}

function setupDrag(w, handle, onClickFn) {
    var x = 0, y = 0, winX = 0, winY = 0, startTime = 0;
    handle.setOnTouchListener(function(v, event) {
        switch (event.getAction()) {
            case event.ACTION_DOWN:
                x = event.getRawX(); y = event.getRawY(); winX = w.getX(); winY = w.getY();
                startTime = Date.now(); return true;
            case event.ACTION_MOVE:
                w.setPosition(winX + (event.getRawX() - x), winY + (event.getRawY() - y)); return true;
            case event.ACTION_UP:
                if (Math.abs(event.getRawX() - x) < 10 && Math.abs(event.getRawY() - y) < 10) {
                    if (Date.now() - startTime < 300 && onClickFn) onClickFn();
                }
                return true;
        } return true;
    });
}

setupDrag(mw, mw.mw_move, function() {
    ui.run(() => {
        mw.mw_move.setVisibility(8); mw.setSize(0, 0);
        fw.setPosition((device.width - TOOLBAR_WIDTH) / 2, dp(50));
        fw.setSize(-2, -2); fw.fw_move.setVisibility(0);
    });
});

setupDrag(rw, rw.run_move, function() {
    isRunning = false;
    engines.all().forEach(e => {
        if (e.getSource().toString().indexOf("AllScr.js") > -1) e.forceStop();
    });
    ui.run(() => {
        rw.run_move.setVisibility(8); rw.setSize(0, 0);
        fw.setPosition((device.width - TOOLBAR_WIDTH) / 2, dp(50));
        fw.setSize(-2, -2); fw.fw_move.setVisibility(0);
    });
});

fw.btn_mini.click(() => {
    ui.run(() => {
        fw.fw_move.setVisibility(8); fw.setSize(0, 0);
        pw.pw_move.setVisibility(8); pw.setSize(0, 0);
        fixMiniPosition();
    });
});

setupDrag(fw, fw.fw_move); setupDrag(pw, pw.pw_move);

threads.start(function(){
    while (!(fw && fw.toolbar_bg && pw && pw.pw_card)) sleep(100);
    ui.run(() => {
        var bgStyle = makeRoundDrawable("#F2242424", dp(15), dp(1), "#88FFFFFF");
        fw.toolbar_bg.setBackground(makeRoundDrawable("#DD2B2B2B", dp(20), dp(1.2), "#BBFFFFFF"));
        pw.pw_card.setBackground(bgStyle);
        ['cbDoiOre', 'cbClaimRe', 'cbBuySky', 'cbBuyBazaar', 'cbBuyDuel'].forEach(id => {
            tintCheckboxWhite(pw[id]);
        });
        pw.btn_picker_back.click(() => {
            pw.layout_picker.setVisibility(8);
            pw.pw_title.setText("CẤU HÌNH");
            pw.layout_setting.setVisibility(0);
        });
        pw.picker_list.on("item_bind", function(itemView, itemHolder) {
            itemView.item_click.on("click", function() {
                var val = String(itemHolder.item);
                if(currentPickerCb) currentPickerCb(val);
                pw.layout_picker.setVisibility(8);
                pw.layout_setting.setVisibility(0);
            });
        });
        loadDataToUi();
    });
});

function loadDataToUi() {
    ui.run(() => {
        pw.valDelay.setText(String(state.delay));
        pw.valBuyRaid.setText(String(state.buy_raid));
        pw.valDiemGlory.setText(String(state.diemGlory_value));
        pw.valMBatdau.setText(String(state.m_batdau));
        pw.valMKetthuc.setText(String(state.m_ketthuc));
        var f = state.flags || {};
        pw.cbDoiOre.checked = !!f.doiore; 
        pw.cbClaimRe.checked = !!f.claimre; 
        pw.cbBuySky.checked = !!f.buysky;
        pw.cbBuyBazaar.checked = !!f.buybazaar; 
        pw.cbBuyDuel.checked = !!f.buyduel; 
    });
}

function chooseList(title, items, cb){
    currentPickerCb = cb;
    ui.run(() => {
        pw.picker_title.setText(title);
        pw.picker_list.setDataSource(items);
        pw.layout_setting.setVisibility(8);
        pw.layout_picker.setVisibility(0);
    });
}

function showSettingFor(btnName) {
    ui.run(() => {
        pw.layout_picker.setVisibility(8);
        pw.layout_setting.setVisibility(0);
        updateButtonHighlights(btnName);
        pw.container_valDelay.setVisibility(8); pw.container_valBuyRaid.setVisibility(8);
        pw.container_valDiemGlory.setVisibility(8); pw.container_valMBatdau.setVisibility(8);
        pw.container_valMKetthuc.setVisibility(8); pw.checkbox_area.setVisibility(8);
        ['cbDoiOre', 'cbClaimRe', 'cbBuySky', 'cbBuyBazaar', 'cbBuyDuel'].forEach(id => pw[id].setVisibility(8));
        
        pw.pw_title.setText("SETTING: " + (btnName === 'duel' ? 'Duel' : cap(btnName)));
        
        switch(btnName) {
            case 'raid': pw.container_valDelay.setVisibility(0); pw.container_valBuyRaid.setVisibility(0); pw.container_valDiemGlory.setVisibility(0); break;
            case 'trial': pw.container_valMBatdau.setVisibility(0); pw.container_valMKetthuc.setVisibility(0); break;
            case 'mine': pw.checkbox_area.setVisibility(0); pw.cbDoiOre.setVisibility(0); pw.cbClaimRe.setVisibility(0); break;
            case 'sky': pw.checkbox_area.setVisibility(0); pw.cbBuySky.setVisibility(0); break;
            case 'reward': pw.checkbox_area.setVisibility(0); pw.cbBuyBazaar.setVisibility(0); break;
            case 'duel': pw.checkbox_area.setVisibility(0); pw.cbBuyDuel.setVisibility(0); break; 
            case 'gauntlet': break;
            case 'explorer': break;
        }

        var btnView = fw["btn_" + btnName];
        var location = java.lang.reflect.Array.newInstance(java.lang.Integer.TYPE, 2);
        btnView.getLocationOnScreen(location);
        
        var pw_w = dp(220); 
        var targetX = location[0] + (btnView.getWidth() / 2) - (pw_w / 2);
        var targetY = location[1] + btnView.getHeight() + dp(5);

        if(targetX < 10) targetX = 10;
        if(targetX + pw_w > device.width) targetX = device.width - pw_w - 10;

        pw.setPosition(targetX, targetY);
        pw.setSize(pw_w, -2);
        pw.pw_move.setVisibility(0);

        pw.pw_card.animate().alpha(1).translationY(0).scaleX(1).scaleY(1).setDuration(300).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    });
}
/* ===== HÀM ĐỌC PHIÊN BẢN TẠI CHỖ ===== */
function getLocalVersion(path) {
    if (!files.exists(path)) return 0;
    try {
        var content = files.read(path);
        var match = content.match(/\/\/\s*version:\s*([\d\.]+)/);
        return match ? parseFloat(match[1]) : 0;
    } catch (e) { return 0; }
}

btnKeys.forEach(k => {
    fw['btn_' + k].click(() => {
        if (isSettingMode) showSettingFor(k);
        else startRunning(k); 
    });
});

fw.btn_control.click(() => {
    if (!isSettingMode) {
        isSettingMode = true;
        ui.run(() => {
            fw.tw_title.setText("CHỌN MỤC CẦN CẤU HÌNH");
            fw.img_control.setSource("file://" + TEMPLATES_DIR + "/save.png");
            fw.txt_control.setText("Save");
            showSettingFor('raid'); 
        });
    } else {
        state.delay = pw.valDelay.getText().toString();
        state.buy_raid = pw.valBuyRaid.getText().toString();
        state.diemGlory_value = pw.valDiemGlory.getText().toString();
        state.m_batdau = pw.valMBatdau.getText().toString();
        state.m_ketthuc = pw.valMKetthuc.getText().toString();
        state.flags = {
            doiore: pw.cbDoiOre.checked, 
            claimre: pw.cbClaimRe.checked, 
            buysky: pw.cbBuySky.checked, 
            buybazaar: pw.cbBuyBazaar.checked,
            buyduel: pw.cbBuyDuel.checked
        };
        writeJson(CONFIG_PATH, state);
        isSettingMode = false;
        ui.run(() => {
            fw.tw_title.setText("AUTO DECKX - BY STORM");
            fw.img_control.setSource("file://" + TEMPLATES_DIR + "/setting.png");
            fw.txt_control.setText("Setting");
            pw.setSize(0, 0); pw.pw_move.setVisibility(8); updateButtonHighlights(null);
        });
    }
});

fw.btn_update.click(() => {
    var updateUrl = "https://drive.google.com/uc?export=download&id=15EiF6xSx4fGL4JnXJjL3EapesbMGxNcI";
    var currentVer = getLocalVersion(SCRIPT_ALL);
    var zipPath = DIR + "/update.tmp.zip"; // File tạm

    threads.start(function() {
        try {
            var res = http.get(updateUrl);
            if (res.statusCode == 200) {
                var server = res.body.json();
                
                if (server.version > currentVer) {
                    confirm("🚀 Nâng cấp toàn diện v" + server.version, server.note)
                    .then(ok => {
                        if (ok) {
                            toast("⏳ Đang tải gói cập nhật (ZIP)...");
                            var zipRes = http.get(server.zip_url);
                            
                            if (zipRes.statusCode == 200) {
                                // 1. Lưu file ZIP vào máy
                                files.writeBytes(zipPath, zipRes.body.bytes());
                                
                                // 2. Giải nén đè lên thư mục gốc (DIR)
                                // Hàm này sẽ tự tạo folder nếu chưa có và ghi đè file cũ
                                files.X(zipPath, DIR);
                                
                                // 3. Xóa file ZIP tạm để dọn rác cho Note 10
                                files.remove(zipPath);
                                
                                toastLog("✅ Đã cập nhật xong " + server.version + "!");
                                
                                // Nếu có UI.js mới thì báo sếp khởi động lại
                                alert("Hoàn tất!", "Hệ thống đã cập nhật ảnh và kịch bản. Sếp khởi động lại bot nhé!");
                            }
                        }
                    });
                } else {
                    toast("✨ Bản hiện tại đã là mới nhất.");
                }
            }
        } catch (e) {
            toast("✖ Lỗi tải gói ZIP: " + e);
        }
    });
});
pw.rowDelay.click(() => chooseList("GIÂY ĐỢI", Delay_Name, v => ui.run(() => pw.valDelay.setText(v))));
pw.rowBuyRaid.click(() => chooseList("MUA RAID", BuyRaid_Data, v => ui.run(() => pw.valBuyRaid.setText(v))));
pw.rowDiemGlory.click(() => chooseList("MỐC GLORY", DiemGlory, v => ui.run(() => pw.valDiemGlory.setText(v))));
pw.rowMBatdau.click(() => chooseList("MAP ĐẦU", DanhSach120, v => ui.run(() => pw.valMBatdau.setText(v))));
pw.rowMKetthuc.click(() => chooseList("MAP CUỐI", DanhSach120, v => ui.run(() => pw.valMKetthuc.setText(v))));

setInterval(() => {}, 1000);