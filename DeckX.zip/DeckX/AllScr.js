// File: AllScr.js
"auto";
var DIR = "/sdcard/Pictures/DeckX";

// 1. Nạp thư viện lõi
delete require.cache[require.resolve(DIR + "/hamCN.js")];
var h = require(DIR + "/hamCN.js");

// 2. Nạp dữ liệu
var cfg = h.readJson(DIR + "/config.json", { flags: {} });
var data = h.readJson(DIR + "/du_lieu.json", {});

// 3. Khởi tạo
if (!requestScreenCapture(false)) { toast("Lỗi màn hình"); exit(); }
h.init(data);



// --- AllScr.js: Phần điều phối logic ---
var logicDir = DIR + "/logic/";

try {
    // 1. Chạy Raid
    if (h.toBool(cfg.raid)) {
        delete require.cache[require.resolve(logicDir + "raid.js")];
        require(logicDir + "raid.js")(h, cfg, data);
    }
    // 2. Chạy Trial
    if (h.toBool(cfg.trial)) {
        delete require.cache[require.resolve(logicDir + "trial.js")];
        require(logicDir + "trial.js")(h, cfg, data);
    }
    // 3. Chạy Mine
    if (h.toBool(cfg.mine)) {
        delete require.cache[require.resolve(logicDir + "mine.js")];
        require(logicDir + "mine.js")(h, cfg, data);
    }
    // 4. Chạy Duel
    if (h.toBool(cfg.duel)) {
        delete require.cache[require.resolve(logicDir + "duel.js")];
        require(logicDir + "duel.js")(h, cfg, data);
    }
    // 5. Chạy Gauntlet
    if (h.toBool(cfg.gauntlet)) {
        delete require.cache[require.resolve(logicDir + "gauntlet.js")];
        require(logicDir + "gauntlet.js")(h, cfg, data);
    }
    // 6. Chạy Explorer
    if (h.toBool(cfg.explorer)) {
        delete require.cache[require.resolve(logicDir + "explorer.js")];
        require(logicDir + "explorer.js")(h, cfg, data);
    }

} catch (e) {
    log("✖ Lỗi kịch bản tại: " + e);
}

toastLog("🏁 TẤT CẢ NHIỆM VỤ ĐÃ HOÀN THÀNH!");
//h.clickVibrate();
exit();