// File: /sdcard/Pictures/DeckX/logic/gauntlet.js
module.exports = function(h, cfg, DU_LIEU) {
    log("🛡️ Bắt đầu chế độ GAUNTLET...");
    var Home = true, fl_SearchGaun = false;

    while (true) {
        java.lang.System.gc(); // Dọn RAM Note 10/Poco
        if (Home) {
            if (h.tap_hinh("Secret")) sleep(1200);
            else if (h.tap_hinh("Gauntlet_main")) sleep(1500);
            else if (h.tim_hinh("SearchGaun")) {
                Home = false; fl_SearchGaun = true;
                toast("Đã vào menu Gauntlet");
            } else {
                h.tap_hinh("BackBut");
            }
        }

        if (fl_SearchGaun) {
            if (h.tim_hinh("inBattleAuto")) {
                h.tap_hinh("inBattleAuto"); sleep(500);
                h.tap_hinh("inBattleSkip");
            } 
            else if (h.tim_hinh("BattleGaun")) {
                h.tap_hinh("BattleGaun"); sleep(500);
            }
            else if (h.tim_hinh("TeamGaun")) {
                h.tap_hinh("TeamGaun"); sleep(500);
            }
            else if (h.tim_hinh("SearchGaun")) {
                h.tap_hinh("SearchGaun"); sleep(800);
                // Nếu sếp muốn giới hạn số trận thì thêm OCR check ở đây
            }
        }
        h.clearScreen(); sleep(800);
    }
};