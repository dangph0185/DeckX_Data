// File: /sdcard/Pictures/DeckX/logic/trial.js
module.exports = function(h, cfg, DU_LIEU) {
    log("🚀 Bắt đầu chế độ TRIAL...");
    
    var Home = true, fl_OCR = false, fl_Battle = false, fl_Skip = false;
    var mKetThuc = parseInt(cfg.m_ketthuc) || 120;

    while (true) {
        if (Home) {
            if (h.tim_hinh("Secret")) {
                h.tap_hinh("Secret");
            } else if (h.tim_hinh("Trial_main")) {
                h.tap_hinh("Trial_main");
            } else if (h.tim_hinh("Continue_Trial")) {
                h.tap_hinh("Continue_Trial");
                sleep(1000); Home = false; fl_OCR = true;
            } else if (h.tim_hinh_mau("Rush")) {
                var curentMap = h.OCR("TrialNum");
                if (curentMap == 0) {
                    h.tap_hinh_mau("Rush");
                    sleep(5000);
                } else if (curentMap < mKetThuc) {
                    Home = false; fl_OCR = true;
                } else {
                    toastLog("🛑 Trial đã đạt mốc: " + curentMap);
                    return; // Kết thúc file, quay về AllScr.js
                }
            }
            sleep(1000);
        }

        while (fl_OCR) {
            if (h.tim_hinh_mau("Rush")) {
                var curentMap = h.OCR("TrialNum");
                if (curentMap < mKetThuc) {
                    if (h.tap_hinh_mau("Rush")) {
                        fl_OCR = false; fl_Battle = true;
                    }
                } else {
                    toastLog("✅ Hoàn thành mục tiêu Trial.");
                    return;
                }
            }
            h.clearScreen(); sleep(1000);
        }

        while (fl_Battle) {
            h.tap_hinh("inBattleAuto");
            if (h.tap_hinh("inBattleSkip")) {
                fl_Battle = false; fl_Skip = true;
            }
            h.clearScreen(); sleep(1000);
        }

        while (fl_Skip) {
            if (h.tim_hinh_mau("Rush")) {
                fl_Skip = false; fl_OCR = true;
            } else {
                back(); sleep(1000);
            }
            h.clearScreen();
        }
        h.clearScreen(); sleep(500);
    }
};