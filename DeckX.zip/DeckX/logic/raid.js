// File: /sdcard/Pictures/DeckX/logic/raid.js

module.exports = function(h, cfg, DU_LIEU) {
    log("🚀 Bắt đầu chế độ RAID...");
    
    // Các biến trạng thái riêng của Raid
    var Home = true, fl_Battle = false, fl_Skip = false, fl_Search = true, fl_OCR = false;
    var mocGlory = parseInt(cfg.diemGlory_value) || 35000;
    var delayTime = parseFloat(cfg.delay) || 1;

    while (true) { // Vòng lặp chính của Raid
        if (Home) {
            h.tap_hinh("Colose");
            h.tap_hinh("Raids");
            if (h.tim_hinh("inSearchGreen")) { 
                fl_Search = false; fl_OCR = true; Home = false; 
            }
        }

        if (fl_Search) {
            if (h.tap_hinh("Search")) {
                sleep(5000);
                if (h.tim_hinh("No_Tries")) {
                    toastLog("🛑 Hết lượt Raid!");
                    return; // Thoát hàm để quay về AllScr.js
                }
            }
        }
        
        // ... (Copy nốt logic Raid của sếp vào đây) ...
        
        h.clearScreen();
        sleep(500);
    }
};