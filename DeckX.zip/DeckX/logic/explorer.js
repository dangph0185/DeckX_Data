// File: /sdcard/Pictures/DeckX/logic/explorer.js
module.exports = function(h, cfg, DU_LIEU) {
    log("🧭 Bắt đầu chế độ EXPLORER...");
    var Home = true, fl_Spin = false;

    while (true) {
        java.lang.System.gc();
        if (Home) {
            if (h.tim_hinh("Main")) {
                h.tap_diem(626, 450); sleep(1200);
            } else if (h.tap_hinh("Campaign")) {
                sleep(1500);
            } else if (h.tap_hinh("SpinMini")) {
                sleep(1500);
            } else if (h.tap_hinh_mau("Enter") || h.tap_hinh("Reset")) {
                sleep(1500);
            } else if (h.tap_hinh("YesExplorer")) {
                sleep(1500); h.tap_diem(626, 450);
            } else if (h.tim_hinh_mau("SpinBig")) {
                Home = false; fl_Spin = true;
            }
        }

        if (fl_Spin) {
            if (h.tim_hinh_mau("SpinBig")) {
                h.tap_hinh("SpinBig"); sleep(4000);
            } else if (h.tim_hinh("ContinueExplorer")) {
                h.tap_hinh("ContinueExplorer"); sleep(1000);
            } else if (h.tim_hinh_mau("inBattleAuto")) {
                h.tap_hinh("inBattleAuto"); sleep(1000);
            } else if (h.tim_hinh("inBattleSkip")) {
                h.tap_hinh("inBattleSkip"); sleep(800);
            } else if (h.tim_hinh("Cleared") || h.tim_hinh("SpinMini")) {
                h.tap_diem(626, 450); sleep(2000);
                toastLog("✅ Đã dọn dẹp xong Explorer.");
                return; // Quay về
            } else {
                h.tap_diem(626, 450); sleep(1000);
            }
        }
        h.clearScreen(); sleep(800);
    }
};