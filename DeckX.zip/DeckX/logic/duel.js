// File: /sdcard/Pictures/DeckX/logic/duel.js
module.exports = function(h, cfg, DU_LIEU) {
    log("⚔️ Bắt đầu chế độ DUEL...");
    
    var Home = true, fl_FindMatch = false, fl_Battle = false, fl_Skip = false;
    var isBuyDuel = h.toBool(cfg.flags.buyduel);

    while (true) {
        if (Home) {
            if (h.tap_hinh("Claim_Reward")) {
                sleep(2000); h.tap_diem(500, 500); sleep(1000);
            }
            if (h.tim_hinh("Main")) h.tap_diem(626, 450);
            h.tap_hinh("DeckDuel");
            if (h.tim_hinh("FindMatch")) {
                Home = false; fl_FindMatch = true;
            }
            sleep(1000);
        }

        while (fl_FindMatch) {
            if (h.tim_hinh("FindMatch")) {
                var curentDuel = h.OCR("DuelNum");
                if (curentDuel > 0) {
                    h.tap_hinh("FindMatch");
                } else {
                    if (isBuyDuel) {
                        h.tap_hinh("BuyDuel"); sleep(1000); h.tap_hinh("OkBuyDuel");
                    } else {
                        h.tap_hinh("BackBut"); sleep(1000);
                        return; // Hết lượt thì thoát
                    }
                }
            } else if (h.tim_hinh("ExitBattleStart")) {
                h.tap_hinh("ExitBattleStart"); sleep(1000);
            } else if (h.tim_hinh("ExitBattleFea")) {
                fl_FindMatch = false; fl_Battle = true;
            } else if (h.tim_hinh("inBattleAuto")) {
                h.tap_hinh("inBattleAuto"); sleep(1000);
            }
            h.clearScreen(); sleep(1000);
        }

        while (fl_Battle) {
            if (h.tim_hinh("ExitBattleFea")) {
                h.tap_hinh("AutoDuel"); sleep(500);
                h.tap_hinh("ApplyDuel"); sleep(500);
                if (h.tim_hinh("ExitBattleFea")) {
                    fl_Battle = false; fl_Skip = true;
                }
            }
            h.clearScreen(); sleep(1000);
        }

        while (fl_Skip) {
            if (h.tim_hinh("FindMatch")) {
                fl_Skip = false; fl_FindMatch = true;
            } else {
                back(); sleep(1000);
            }
            h.clearScreen();
        }
        h.clearScreen(); sleep(500);
    }
};