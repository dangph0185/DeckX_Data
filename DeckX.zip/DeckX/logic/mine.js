// File: /sdcard/Pictures/DeckX/logic/mine.js
module.exports = function(h, cfg, DU_LIEU) {
    log("💎 Bắt đầu chế độ MINE...");
    var Home = true, fl_Search_Mine = false;
    var isDoiOre = h.toBool(cfg.flags.doiore);

    while (true) {
        if (Home) {
            h.tap_hinh("Secret");
            h.tap_hinh("Mine_main");
            h.tap_hinh("Enter_Mine");
            if (h.tim_hinh("Search_Mine")) {
                fl_Search_Mine = true; Home = false;
            }
        }
        while (fl_Search_Mine) {
            h.tap_hinh("Search_Mine", 0.95);
            if (isDoiOre) h.tap_hinh("Ore_Ex");
            else h.tap_hinh("Claim_Re");

            if (h.tim_hinh("again")) {
                toastLog("✅ Đã hoàn thành Mine.");
                return; // Thoát về AllScr.js
            }
            h.clearScreen(); sleep(1000);
        }
        h.clearScreen(); sleep(1000);
    }
};