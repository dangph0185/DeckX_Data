/**
 * hamCN.js - Thư viện lõi hỗ trợ DeckX
 */
var hamCN = {
    // Kho chứa dữ liệu nội bộ
    DU_LIEU: null,
    TEMPLATE_CACHE: {},
    SCREEN_CACHE: null,
    
    // Thông số màn hình gốc của Template
    BASE_W: 1280,
    BASE_H: 720,
    
    // Thông số vùng Game thực tế (Sẽ được tính toán tự động)
    GAME: { x: 0, y: 0, w: 0, h: 0 },
    SCALE: 1,
    DIR: "/sdcard/Pictures/DeckX",
    TEMPLATE_PATH: "/sdcard/Pictures/DeckX/templates"
};

// =====================================================
// 1. KHỞI TẠO & CẤU HÌNH (GỌI 1 LẦN ĐẦU)
// =====================================================
hamCN.init = function(data) {
    this.DU_LIEU = data;
    this.detectGameArea();
    log("✅ hamCN: Đã nạp Database và tính toán tỉ lệ màn hình.");
};

hamCN.detectGameArea = function() {
    var sw = device.width;
    var sh = device.height;
    var targetRatio = 16 / 9;
    var screenRatio = sw / sh;

    if (screenRatio > targetRatio) {
        this.GAME.h = sh;
        this.GAME.w = parseInt(sh * targetRatio);
        this.GAME.x = parseInt((sw - this.GAME.w) / 2);
    } else {
        this.GAME.w = sw;
        this.GAME.h = parseInt(sw / targetRatio);
        this.GAME.y = parseInt((sh - this.GAME.h) / 2);
    }
    this.SCALE = this.GAME.h / this.BASE_H;
};

// =====================================================
// 2. TIỆN ÍCH HỆ THỐNG
// =====================================================
hamCN.readJson = function(path, fb) {
    try {
        if (files.exists(path)) return JSON.parse(String(files.read(path)));
    } catch (e) { log("✖ Lỗi đọc file: " + path); }
    return fb;
};

hamCN.toBool = function(v) {
    if (typeof v === "boolean") return v;
    if (typeof v === "string") {
        var s = v.trim().toLowerCase();
        return s === "1" || s === "true" || s === "on";
    }
    return !!v;
};

// =====================================================
// 3. XỬ LÝ HÌNH ẢNH & SCALE
// =====================================================
hamCN.scaleRegion = function(r) {
    if (!r) return null;
    return [
        parseInt(r[0] * this.SCALE + this.GAME.x),
        parseInt(r[1] * this.SCALE + this.GAME.y),
        parseInt(r[2] * this.SCALE),
        parseInt(r[3] * this.SCALE)
    ];
};

hamCN.getTemplate = function(name) {
    if (this.TEMPLATE_CACHE[name]) return this.TEMPLATE_CACHE[name];
    
    var fileName = this.DU_LIEU.images[name];
    var path = files.join(this.TEMPLATE_PATH, fileName);
    var img = images.read(path);
    if (!img) return null;

    // Resize template theo màn hình thực tế
    var w = parseInt(img.getWidth() * this.SCALE);
    var h = parseInt(img.getHeight() * this.SCALE);
    var resized = images.resize(img, [w, h]);
    img.recycle();

    this.TEMPLATE_CACHE[name] = resized;
    return resized;
};

hamCN.getScreen = function() {
    if (this.SCREEN_CACHE == null) this.SCREEN_CACHE = captureScreen();
    return this.SCREEN_CACHE;
};

hamCN.clearScreen = function() {
    if (this.SCREEN_CACHE) {
        this.SCREEN_CACHE.recycle();
        this.SCREEN_CACHE = null;
    }
};

// =====================================================
// 4. CÁC HÀM TỰ ĐỘNG HÓA (API CHÍNH)
// =====================================================

// Tìm hình cơ bản
hamCN.tim_hinh = function(name, thr) {
    thr = thr || 0.85;
    var tpl = this.getTemplate(name);
    var scr = this.getScreen();
    var r = this.scaleRegion(this.DU_LIEU.regions[name]);
    return !!images.findImage(scr, tpl, { region: r, threshold: thr });
};

// Nhấn hình cơ bản
hamCN.tap_hinh = function(name, thr) {
    thr = thr || 0.85;
    var tpl = this.getTemplate(name);
    var scr = this.getScreen();
    var r = this.scaleRegion(this.DU_LIEU.regions[name]);
    var p = images.findImage(scr, tpl, { region: r, threshold: thr });
    if (p) {
        click(p.x + tpl.getWidth() / 2, p.y + tpl.getHeight() / 2);
        return true;
    }
    return false;
};

// Tìm hình + Check màu (Tránh nút bị xám)
hamCN.tim_hinh_mau = function(name, thr) {
    thr = thr || 0.85;
    var tpl = this.getTemplate(name);
    var scr = this.getScreen();
    var r = this.scaleRegion(this.DU_LIEU.regions[name]);
    var p = images.findImage(scr, tpl, { region: r, threshold: thr });
    return (p && this.checkColorStandard(scr, p, tpl));
};

// Nhấn hình + Check màu
hamCN.tap_hinh_mau = function(name, thr) {
    thr = thr || 0.85;
    var tpl = this.getTemplate(name);
    var scr = this.getScreen();
    var r = this.scaleRegion(this.DU_LIEU.regions[name]);
    var p = images.findImage(scr, tpl, { region: r, threshold: thr });
    if (p && this.checkColorStandard(scr, p, tpl)) {
        click(p.x + tpl.getWidth() / 2, p.y + tpl.getHeight() / 2);
        return true;
    }
    return false;
};

// Thuật toán kiểm tra màu (Saturation)
hamCN.checkColorStandard = function(scr, p, tpl) {
    var w = tpl.getWidth(), h = tpl.getHeight();
    var maxSat = 0;
    var steps = [0.25, 0.5, 0.75];
    for (var i = 0; i < 3; i++) {
        for (var j = 0; j < 3; j++) {
            var color = images.pixel(scr, p.x + (w * steps[i]), p.y + (h * steps[j]));
            var r = colors.red(color), g = colors.green(color), b = colors.blue(color);
            var diff = Math.max(r, g, b) - Math.min(r, g, b);
            if (diff > maxSat) maxSat = diff;
            if (maxSat > 35) break;
        }
    }
    return maxSat > 20;
};

// Nhấn tọa độ (Tự scale theo 1280x720)
hamCN.tap_diem = function(x, y) {
    var tx = Math.round(this.GAME.x + x * this.GAME.w / this.BASE_W);
    var ty = Math.round(this.GAME.y + y * this.GAME.h / this.BASE_H);
    click(tx, ty);
};

// Nhận diện số (OCR)
hamCN.OCR = function(name) {
    var rOriginal = this.DU_LIEU.regions[name];
    if (!rOriginal) return 0;
    var r = this.scaleRegion(rOriginal);
    var scr = this.getScreen();
    var clip = null;
    try {
        clip = images.clip(scr, r[0], r[1], r[2], r[3]);
        var result = gmlkit.ocr(clip, "en");
        if (!result || !result.text) return 0;
        var num = parseInt(result.text.replace(/[^0-9]/g, ""));
        return isNaN(num) ? 0 : num;
    } catch (e) {
        log("OCR error: " + e);
        return 0;
    } finally {
        if (clip) clip.recycle();
    }
};

module.exports = hamCN;